import requests, zipfile, io, json

################################################################################
################################################################################
################################################################################

# data = {"username":"gabo"}

# files = [
#     ('files', open('test.zip','rb')),
#     ('data', json.dumps(data)),
# ]

# req = requests.post('http://127.0.0.1:5000/kai-api/upload-file', files=files)

# print(req.content)

################################################################################
################################################################################
################################################################################

data = {"pathResult":r"gabo\output\test.zip"}

req = requests.get('http://127.0.0.1:5000/kai-api/download-file', data=json.dumps(data))

if req.ok:
    zipFile = zipfile.ZipFile(io.BytesIO(req.content))
    zipFile.extractall()