from flask import Blueprint, request
from controllers.file import upload_file_controller, download_file_controller

file_route = Blueprint('file_route',__name__)

@file_route.route('/kai-api/upload-file', methods=['POST'])
def upload_file():
    return upload_file_controller(request)

@file_route.route('/kai-api/download-file', methods=['GET'])
def download_file():
    return download_file_controller(request)