from flask import jsonify, send_file
from services.create_temp_folder import create_temp_folder
from services.download_zip_result import download_zip_result
import json

def upload_file_controller(request):
    if 'files' not in request.files:
        resp = jsonify({'message' : 'No file part in the request'})
        resp.status_code = 400
        return resp
    
    file = request.files['files']
    username = json.load(request.files['data'])['username']

    if file.filename.rsplit('.')[1] != 'zip':
        resp = jsonify({'message' : 'The uploaded file is not a zip'})
        resp.status_code = 400
        return resp
    
    success = create_temp_folder(file, username)

    if not success:
        resp.status = 400
        return resp
    
    resp = jsonify({'message' : 'Files successfully uploaded'})
    resp.status_code = 200
    return resp


def download_file_controller(request):
    try:
        path_result = json.loads(request.data)['pathResult']
    
        zip_file = download_zip_result(path_result)

        resp = jsonify({'message' : 'Files successfully download'})
        resp.status_code = 200

        return resp and zip_file
    
    except:
        resp = jsonify({'message' : 'Something was wrong'})
        resp.status_code = 400
        return resp