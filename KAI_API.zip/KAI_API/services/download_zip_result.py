import os, zipfile
from flask import send_file

TEMP_FOLDER = r"C:\Users\Gabriel Bonilla\Desktop\temp_data"

def download_zip_result(path):
    downloadPath = os.path.join(TEMP_FOLDER, path)  
    return send_file(downloadPath, mimetype = 'zip', as_attachment = True)