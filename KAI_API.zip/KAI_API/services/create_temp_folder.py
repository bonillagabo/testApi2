import os

TEMP_FOLDER = r"C:\Users\Gabriel Bonilla\Desktop\temp_data"

def create_temp_folder(file, username):
    try:
        input_path = f'{TEMP_FOLDER}\\{username}\\input'

        if not os.path.exists(input_path):
            os.makedirs(input_path)
    
        file.save(os.path.join(input_path, file.filename))

        return True
    except:
        return False

    